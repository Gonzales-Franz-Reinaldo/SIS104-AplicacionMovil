package com.example.proyectokotlin.ejercicios

data class Multiplicacion(val a: Int, val b: Int)
