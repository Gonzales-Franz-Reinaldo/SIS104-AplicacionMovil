package com.example.proyectokotlin.ejercicios

data class Person(val name: String, val email: String)
