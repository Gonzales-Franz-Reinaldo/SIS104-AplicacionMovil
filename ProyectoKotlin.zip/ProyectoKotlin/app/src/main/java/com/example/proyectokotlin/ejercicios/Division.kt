package com.example.proyectokotlin.ejercicios

data class Division(val a: Int, val b: Int)
