package com.example.proyectokotlin

import android.content.ClipDescription
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proyectokotlin.basedatos.BaseDatosActivity
import com.example.proyectokotlin.basedatos.DBHelper
import com.example.proyectokotlin.basedatos.Lugar
import com.example.proyectokotlin.ejercicios.EjerciciosActivity
import com.example.proyectokotlin.ejercicios.PersonActivity
import com.example.proyectokotlin.examen.ExamenActivity
import com.example.proyectokotlin.graficos.GraficosActivity

class MainActivity : AppCompatActivity() {

    lateinit var dbHelper: DBHelper

//    lateinit var editTextId: EditText
//    lateinit var editTextNombre: EditText
//    lateinit var editTextDescripcion: EditText
//    lateinit var buttonAgregar: Button
//    lateinit var buttonListar: Button
//    lateinit var buttonActualizar: Button
//    lateinit var buttonEliminar: Button
//    lateinit var textViewMostrarDatos: TextView

    lateinit var editTextId:EditText
    lateinit var editTextNombre:EditText
    lateinit var editTextDescripcion:EditText
    lateinit var textViewResultado : TextView

    lateinit var buttonAgregar: Button
    lateinit var buttonListar: Button
    lateinit var buttonEditar: Button
    lateinit var buttonEliminar: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        PARA LA BASE DE DATOS
        dbHelper = DBHelper(this)
//        editTextId = findViewById(R.id.editTextId)
//        editTextNombre = findViewById(R.id.editTextNombre)
//        editTextDescripcion = findViewById(R.id.editTextDescripcion)
//        buttonAgregar = findViewById(R.id.buttonAgregar)
//        buttonListar = findViewById(R.id.buttonListar)
//        textViewMostrarDatos = findViewById(R.id.textViewMostrarDatos)
//        buttonActualizar = findViewById(R.id.buttonActualizar)
//        buttonEliminar = findViewById(R.id.buttonEliminar)

        editTextId = findViewById(R.id.editTextId)
        editTextNombre = findViewById(R.id.editTextNombre)
        editTextDescripcion = findViewById(R.id.editTextDescripcion)
        buttonAgregar = findViewById(R.id.buttonAgregar)
        buttonListar = findViewById(R.id.buttonListar)
        textViewResultado = findViewById(R.id.textViewResultado)
        buttonEditar = findViewById(R.id.buttonEditar)
        buttonEliminar = findViewById(R.id.buttonEliminar)





//        val buttonBaseDatos = findViewById<Button>(R.id.buttonBaseDatos)
//        val buttonEjercicios = findViewById<Button>(R.id.buttonEjercicios)
//        val buttonGraficos = findViewById<Button>(R.id.buttonGraficos)
//        val buttonSalir = findViewById<Button>(R.id.buttonSalir)
//        val buttonExamen = findViewById<Button>(R.id.buttonExamen)
//        val buttonPerson = findViewById<Button>(R.id.buttonPerson)


//        Para la base de datos
//        buttonAgregar.setOnClickListener{
//            agregarLugar()
//        }
//        buttonListar.setOnClickListener{
//            listarLugar()
//        }
//
//        buttonActualizar.setOnClickListener{
//            actualizarLugar()
//        }
//
//        buttonEliminar.setOnClickListener{
//            eliminarLugar()
//        }


        buttonAgregar.setOnClickListener{
            agregarLugar()
        }
        buttonListar.setOnClickListener{
            listarLugar()
        }
        buttonEditar.setOnClickListener{
            editarLugar()
        }
        buttonEliminar.setOnClickListener{
            eliminarLugar()
        }




//        buttonBaseDatos.setOnClickListener{
//            val intent = Intent(this@MainActivity, BaseDatosActivity::class.java)
//            startActivity(intent)
//        }
//        buttonEjercicios.setOnClickListener{
//            val intent = Intent(this@MainActivity, EjerciciosActivity::class.java)
//            startActivity(intent)
//        }
//
//        buttonGraficos.setOnClickListener{
//            val intent = Intent(this@MainActivity, GraficosActivity::class.java)
//            startActivity(intent)
//        }
//        buttonExamen.setOnClickListener{
//            val intent = Intent(this@MainActivity, ExamenActivity::class.java)
//            startActivity(intent)
//        }
//
//        buttonPerson.setOnClickListener{
//            val intent = Intent(this@MainActivity, PersonActivity::class.java)
//            startActivity(intent)
//        }
//
//        buttonSalir.setOnClickListener{
//            finish()
//        }
    }


//    fun agregarLugar(){
//        val nombre = editTextNombre.text.toString()
//        val descripcion = editTextDescripcion.text.toString()
//        val lugar = Lugar(nombre = nombre, descripcion = descripcion)
//        val id = dbHelper.insertarLugar(lugar)
//        textViewMostrarDatos.text = "ID: $id - Nombre: $nombre - Descripción: $descripcion"
//    }
//
//    fun listarLugar(){
//        val listaLugares = dbHelper.obtenerLugares()
//        var texto = ""
//        for(lugar in listaLugares){
//            texto += "ID: ${lugar.id} - Nombre: ${lugar.nombre} - Descripción: ${lugar.descripcion}\n"
//        }
//        textViewMostrarDatos.text = texto
//    }

    fun agregarLugar(){
        val nombre = editTextNombre.text.toString()
        val descripcion = editTextDescripcion.text.toString()
        val lugar = Lugar(0, nombre, descripcion)
        dbHelper.insertarLugar(lugar)
        textViewResultado.text = "Lugar agregado correctamente"
    }
    fun listarLugar(){
        val lugares = dbHelper.obtenerLugares()
        val stringBuilder = StringBuilder()

        for (lugar in lugares) {
            stringBuilder.append("ID: ${lugar.id}\n")
            stringBuilder.append("Nombre: ${lugar.nombre}\n")
            stringBuilder.append("Descripción: ${lugar.descripcion}\n")
            stringBuilder.append("\n")
        }
        textViewResultado.text = stringBuilder.toString()

    }

    fun editarLugar() {
        val id = editTextId.text.toString().toIntOrNull()
        val nombre = editTextNombre.text.toString()
        val descripcion = editTextDescripcion.text.toString()

        if (id != null) {
            val lugar = Lugar(id, nombre, descripcion)
            val filasActualizadas = dbHelper.editarLugar(lugar)
            if (filasActualizadas > 0) {
                textViewResultado.text = "Lugar actualizado correctamente"
            } else {
                textViewResultado.text = "No se pudo actualizar el lugar"
            }
        } else {
            textViewResultado.text = "Por favor, ingrese un ID válido"
        }
    }


    fun eliminarLugar() {
        val id = editTextId.text.toString().toIntOrNull()

        if (id != null) {
            val filasEliminadas = dbHelper.eliminarLugar(id)
            if (filasEliminadas > 0) {
                textViewResultado.text = "Lugar eliminado correctamente"
            } else {
                textViewResultado.text = "No se pudo eliminar el lugar"
            }
        } else {
            textViewResultado.text = "Por favor, ingrese un ID válido"
        }
    }


    //    Agregar la funciones actualizar
//    fun actualizarLugar(){
//        val id = editTextId.text.toString().toInt()
//        val nombre = editTextNombre.text.toString()
//        val descripcion = editTextDescripcion.text.toString()
//        val lugar = Lugar(id = id, nombre = nombre, descripcion = descripcion)
//        val filasAfectadas = dbHelper.actualizarLugar(lugar)
//        textViewMostrarDatos.text = "Filas afectadas: $filasAfectadas"
//    }
//
//    fun eliminarLugar(){
//        val id = editTextId.text.toString().toInt()
//        val filasAfectadas = dbHelper.eliminarLugar(id)
//        textViewMostrarDatos.text = "Filas afectadas: $filasAfectadas"
//    }

}
