package com.example.proyectokotlin.ejercicios

data class Suma(val a: Int, val b: Int)
