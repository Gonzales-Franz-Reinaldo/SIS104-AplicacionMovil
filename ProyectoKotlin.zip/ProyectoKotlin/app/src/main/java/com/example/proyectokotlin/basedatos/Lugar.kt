package com.example.proyectokotlin.basedatos

data class Lugar(
    var id: Int = 0,
    var nombre: String,
    var descripcion: String
)